import React from "react"

export default () => <div>Danielle Morin - Gastby Part 0 Hello world!</div>
